My homework. It computes an average of some numbers.
