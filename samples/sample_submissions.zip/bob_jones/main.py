def average(numbers):
    return sum(numbers) / len(numbers)


print("average:", average([1, 2, 3]))
