# Average Calculator

This program computes the average of a list of numbers using a dedicated
calculate_average function. I tested it with empty lists, single values, and
mixed integers to make sure division by zero never happens. The math module
is used to demonstrate square roots in the demo output. Run the program with
python main.py and it prints the average of the sample data set.
