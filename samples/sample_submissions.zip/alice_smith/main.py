"""Average calculator assignment."""
import math


def calculate_average(numbers):
    if not numbers:
        return 0.0
    return sum(numbers) / len(numbers)


def main():
    data = [2, 4, 6, 8]
    print("average:", calculate_average(data))
    print("sqrt of 16:", math.sqrt(16))


if __name__ == "__main__":
    main()
